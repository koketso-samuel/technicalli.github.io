#include "csiLib.h"

#include <iostream>
#include <cstdlib>
#include <assert.h>
#include <iomanip>


using namespace std;

namespace CrimeSpace {

    // get pseudo random numbers
    int genRandom(int intMin, int intMax) {

        int intRange = intMax - intMin + 1;
        return rand()%intRange + intMin;

    }


    //free memory
    void freeMem(GameWorld& aryWorld, int intRows) {

        for(int x = 0; x < intRows; x++) {
            delete[] aryWorld[x];
        }

        delete[] aryWorld;

    }


    // create array
    gameStruct makeArray(int intRows, int intCols, int intClues, int movesLeft){

        gameStruct game;
        int intPRow = genRandom(0, intRows - 1);
        int intPCol = genRandom(0, intCols - 1);

        game.intPRow = intPRow;
        game.intPCol = intPCol;
        game.intClues = intClues;
        game.intPClues = intClues*2;
        game.intRows = intRows;
        game.intCols = intCols;
        game.intMovesLeft = movesLeft;



        game.aryWorld = new int*[intRows];
        for(int x = 0; x < intRows; x++) {
            game.aryWorld[x] = new int[intCols];

            for(int y = 0; y < intCols; y++) {
                game.aryWorld[x][y] = SPACE;

            }

        }

        game.aryWorld[game.intPRow][game.intPCol] = PLAYER;



        placElement(game.aryWorld, intRows, intCols, game.intClues, UNDISCOVERED_CLUE);
        placElement(game.aryWorld, intRows, intCols, 2*game.intClues, POTENTIAL_CLUE);


        return game;

    };



    // Place game element
    void placElement(GameWorld aryWorld,int intRows, int intCols, int intCount, gamElements elem){

        int intNRow = genRandom(0, intRows - 1);
        int intNCol = genRandom(0, intCols - 1);

        while (intCount > 0) {

            if(aryWorld[intNRow][intNCol] == SPACE) {
                aryWorld[intNRow][intNCol] = elem;
                intCount--;
            }

            intNRow = genRandom(0, intRows - 1);
            intNCol = genRandom(0, intCols - 1);

        }

    };


    bool isInWorld(int intRow, int intCol, gameStruct game){

        if(intRow < game.intRows && intCol < game.intCols && intCol >= 0 && intRow >= 0)
            return true;

        return false;

    };


    // show world
    void showWorld(gameStruct game){

        for(int x = 0; x < game.intRows; x++) {

            for(int y = 0; y < game.intCols; y++) {

                if (game.aryWorld[x][y] == PLAYER) {
                    cout << setw(2) << "P";
                } else if(game.aryWorld[x][y] == CLUE) {
                    cout << setw(2) << "O";
                }else if(game.aryWorld[x][y] == UNDISCOVERED_CLUE) {
                    cout << setw(2) << "#";
                } else if(game.aryWorld[x][y] == POTENTIAL_CLUE) {
                    cout << setw(2) << "#";
                } else {
                    cout << setw(2) << "-";
                }

            }

            cout << endl;

        }

    };


    // move player
    void makeMove(gameStruct& game, movement dir) {

        int intRow = game.intPRow;
        int intCol = game.intPCol;

        switch(dir) {

            case UP:
                intRow--;
                break;
            case DOWN:
                intRow++;
                break;
            case LEFT:
                intCol--;
                break;
            case RIGHT:
                intCol++;
                break;

        }

        // check if the player is in world and that he is not moving through clues or potential clues
        if(isInWorld(intRow, intCol, game) && (game.aryWorld[intRow][intCol]  == SPACE && game.intMovesLeft > 0)) {

            game.aryWorld[intRow][intCol] = PLAYER;
            game.aryWorld[game.intPRow][game.intPCol] = SPACE;
            game.intPRow = intRow;
            game.intPCol = intCol;
            game.intMovesLeft -= 1;

        }

        if(game.intMovesLeft == 0) {
            cout << "NO MOVES LEFT YOU LOST \n";
            system("pause");
            exit(MOVES_EXHAUSTED);
        }


    }

    // menu
    void nenuShow(gameStruct game) {

        cout    << "MOVES LEFT: " << game.intMovesLeft << endl
                << endl
                << "A) Move the player left \n"
                << "D) Move the player right \n"
                << "W) Move the player up \n"
                << "S) Move the payer down \n"
                << "I) INVESTIGATE \n"
                << "X) Quit game \n";

    }


    // investigate
    void investigate(gameStruct& game) {

        // check right
        if(game.aryWorld[game.intPRow][game.intPCol + 1] == UNDISCOVERED_CLUE) {
            game.aryWorld[game.intPRow][game.intPCol + 1] = CLUE;
            game.intCluesDiscovered += 1;
        } else if(game.aryWorld[game.intPRow][game.intPCol + 1] == POTENTIAL_CLUE) {
            game.aryWorld[game.intPRow][game.intPCol + 1] = SPACE;
        }

        // check left
        if(game.aryWorld[game.intPRow][game.intPCol - 1] == UNDISCOVERED_CLUE) {
            game.aryWorld[game.intPRow][game.intPCol - 1] = CLUE;
            game.intCluesDiscovered += 1;
        } else if(game.aryWorld[game.intPRow][game.intPCol - 1] == POTENTIAL_CLUE){
            game.aryWorld[game.intPRow][game.intPCol - 1] = SPACE;
        };

        // check top
        if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol] == UNDISCOVERED_CLUE)) {
           game.aryWorld[game.intPRow - 1][game.intPCol] = CLUE;
           game.intCluesDiscovered += 1;
        } else if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow - 1][game.intPCol] = SPACE;
        }

        // top left
        if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol -1] == UNDISCOVERED_CLUE)) {
           game.aryWorld[game.intPRow - 1][game.intPCol - 1] = CLUE;
           game.intCluesDiscovered += 1;
        } else if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol - 1] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow - 1][game.intPCol - 1] = SPACE;
        }

        // bottom left
        if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol -1] == UNDISCOVERED_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol - 1] = CLUE;
            game.intCluesDiscovered += 1;
        } else if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol - 1] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol - 1] = SPACE;
        }

        // check bottom
        if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol] == UNDISCOVERED_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol] = CLUE;
            game.intCluesDiscovered += 1;
        } else if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol] = SPACE;
        }

        // top right
        if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol + 1] == UNDISCOVERED_CLUE)) {
            game.aryWorld[game.intPRow - 1][game.intPCol + 1] = CLUE;
            game.intCluesDiscovered += 1;
        } else if((game.intPRow > 0) && (game.aryWorld[game.intPRow - 1][game.intPCol + 1] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow - 1][game.intPCol + 1] = SPACE;
        }

        // bottom right
        if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol + 1] == UNDISCOVERED_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol + 1] = CLUE;
            game.intCluesDiscovered += 1;
        } else if((game.intPRow < (game.intRows - 1)) && (game.aryWorld[game.intPRow + 1][game.intPCol + 1] == POTENTIAL_CLUE)) {
            game.aryWorld[game.intPRow + 1][game.intPCol + 1] = SPACE;
        }



    }


    int prompt(string strPrompt) {

        int intVal = 0;
        cout << strPrompt << endl;
        cin >> intVal;

        while (cin.fail())
        {
            cin.clear();
            string strJunk = "";
            cin >> strJunk;
            cout << strPrompt << endl;
            cin >> intVal;

        }

        return intVal;

    }


}
