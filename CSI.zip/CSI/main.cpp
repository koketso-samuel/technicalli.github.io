#include "csiLib.h"

#include <iostream>

#include <cstdlib>
#include <ctime>

using namespace std;
using namespace CrimeSpace;

int main()
{


    srand(time(nullptr));

    int intRows = prompt("Enter the number of rows");
    int intCols = prompt("Enter the number of columns");
    int intClues = prompt("Enter the number of clues");
    int intMoves = prompt("Enter the number of moves");
    gameStruct game = makeArray(intRows, intCols, intClues, intMoves);


    do {


        system("cls");
        showWorld(game);
        nenuShow(game);

        if(game.intClues == game.intCluesDiscovered) {
            cout << "YOU WON! \n";
            system("pause");
            freeMem(game.aryWorld, game.intRows);
            exit(GAME_WON);
        }

        char chMove = '\0';

        cin >> chMove;

        switch(chMove) {

        case 'a':
        case 'A':
            makeMove(game, LEFT);
            break;

        case 'd':
        case 'D':
            makeMove(game, RIGHT);
            break;

        case 'w':
        case 'W':
            makeMove(game, UP);
            break;

        case 's':
        case 'S':
            makeMove(game, DOWN);
            break;

        case 'x':
        case 'X':
            {
                freeMem(game.aryWorld, game.intRows);
                exit(EXIT_SUCCESS);
                break;
            }
        case 'i':
        case 'I':
            investigate(game);

        }




    } while(true);

    system("pause");

    return 0;
}
