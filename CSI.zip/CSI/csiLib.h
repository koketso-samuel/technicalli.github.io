#ifndef CSILIB_H_INCLUDED
#define CSILIB_H_INCLUDED
#include <string>

using namespace std;

namespace CrimeSpace {

    typedef int* GameRow;
    typedef GameRow* GameWorld;
    const int MOVES_EXHAUSTED = 1;
    const int GAME_WON = 2;

    struct gameStruct {

        int intRows;
        int intCols;
        int intClues;
        int intPClues;
        GameWorld aryWorld;
        int intPCol;
        int intPRow;
        int intMovesLeft;
        int intCluesDiscovered = 0;

    };

    enum gamElements {

        PLAYER,
        CLUE,
        POTENTIAL_CLUE,
        SPACE,
        UNDISCOVERED_CLUE

    };

    enum movement {

        UP,
        DOWN,
        LEFT,
        RIGHT

    };

    gameStruct makeArray(int intRows, int intCols, int intClues, int movesLeft);
    void placElement(GameWorld aryWorld,int intRows, int intCols, int intCount, gamElements elem);
    void showWorld(gameStruct game);
    void makeMove(gameStruct& game, movement dir);
    bool isInWorld(int intRow, int intCol, gameStruct game);
    void freeMem(GameWorld& aryWorld, int intRows);
    void nenuShow(gameStruct game);
    void investigate(gameStruct& game);
    int prompt(string strPrompt);

}



#endif // CSILIB_H_INCLUDED
